<?
$MESS["SS_DELETE"] = "Delete";
$MESS["SS_GET_COMPONENT_INFO"] = "Link a profile with a social network or service";
$MESS["SS_NAME"] = "Name";
$MESS["SS_PROFILE_DELETE_CONFIRM"] = "Are you sure you want to delete your profile?";
$MESS["SS_SEND_MESSAGE_TO"] = "Your Twitter posts with hashtag # hash # will be streamed live.";
$MESS["SS_SOCNET"] = "Social network";
$MESS["SS_TO_RECIPIENTS"] = "Specify recipients.";
$MESS["SS_YOUR_ACCOUNTS"] = "Linked accounts";
?>