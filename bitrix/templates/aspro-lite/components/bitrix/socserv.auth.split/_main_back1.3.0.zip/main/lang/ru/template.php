<?
$MESS["SS_GET_COMPONENT_INFO"] = "Связать профиль с соцсетью или сервисом";
$MESS["SS_NAME"] = "Имя";
$MESS["SS_SOCNET"] = "Социальная сеть";
$MESS["SS_YOUR_ACCOUNTS"] = "Связанные аккаунты";
$MESS["SS_DELETE"] = "Удалить";
$MESS["SS_PROFILE_DELETE_CONFIRM"] = "Вы уверены, что хотите удалить профиль?";
$MESS["SS_SEND_MESSAGE_TO"] = "Ваши сообщения из Twitter с хештегом #hash# будут транслироваться в живую ленту.";
$MESS["SS_TO_RECIPIENTS"] = "Указать получателей.";
?>