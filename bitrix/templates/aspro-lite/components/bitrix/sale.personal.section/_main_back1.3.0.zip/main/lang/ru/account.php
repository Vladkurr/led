<?php
$MESS["SPS_TITLE_ACCOUNT"] = "Мои пользовательский счет";
$MESS["SPS_CHAIN_ACCOUNT"] = "Внутренний счет";
$MESS["SPS_CHAIN_MAIN"] = "Мой кабинет";
$MESS["SPS_BUY_MONEY"] = "Пополнение счета";