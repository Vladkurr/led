<?
$MESS["SPS_ACCOUNT_PAGE_NAME"] = "Persцnlicher Account";
$MESS["SPS_PERSONAL_PAGE_NAME"] = "Persцnliche Informationen";
$MESS["SPS_PROFILE_PAGE_NAME"] = "Profile der Bestellungen";
$MESS["SPS_ORDER_PAGE_NAME"] = "Aktuelle Bestellungen";
$MESS["SPS_ORDER_PAGE_HISTORY"] = "Bestellhistory";
$MESS["SPS_SUBSCRIBE_PAGE_NAME"] = "Abonnements";
$MESS["SPS_BASKET_PAGE_NAME"] = "Warenkorb";
$MESS["SPS_CONTACT_PAGE_NAME"] = "Kontakte";
$MESS["SPS_ERROR_NOT_CHOSEN_ELEMENT"] = "Keine Elemente ausgewдhlt";
$MESS["SPS_CHAIN_MAIN"] = "Mein Account";
$MESS["SPS_TITLE_MAIN"] = "Persцnlicher Bereich";
?>