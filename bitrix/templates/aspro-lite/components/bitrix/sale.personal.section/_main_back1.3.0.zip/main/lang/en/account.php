<?
$MESS["SPS_TITLE_ACCOUNT"] = "My Account";
$MESS["SPS_CHAIN_ACCOUNT"] = "Internal account";
$MESS["SPS_CHAIN_MAIN"] = "My account";
$MESS["SPS_BUY_MONEY"] = "Top up account";
?>