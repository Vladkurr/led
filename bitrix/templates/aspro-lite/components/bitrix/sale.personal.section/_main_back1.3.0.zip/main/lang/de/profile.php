<?
$MESS["SPS_CHAIN_MAIN"] = "Mein Account";
$MESS["SPS_CHAIN_PROFILE"] = "Nutzerprofile";
$MESS["SPS_TITLE_PROFILE"] = "Nutzerprofil";
?>