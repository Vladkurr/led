<?php
$MESS['SUBSCRIBE__POPUP__TITLE'] = 'Подписка на рассылку';
$MESS['SUBSCRIBE__POPUP__EMAIL'] = 'Email';
$MESS['SUBSCRIBE__POPUP__SUBMIT'] = 'Подписаться';
$MESS['SUBSCRIBE__POPUP__CLOSE'] = 'Закрыть';
$MESS['SUBSCRIBE__POPUP__SETTINGS'] = 'Настройки';
$MESS['SUBSCRIBE__POPUP__TITLE_SUCCESS'] = 'Спасибо!';
$MESS['SUBSCRIBE__POPUP__MESSAGE_SUCCESS'] = 'На адрес подписки выслан код подтверждения.';
$MESS['SUBSCRIBE__POPUP__VALIDATE_LICENSES'] = 'Согласитесь с условиями';