<?
$MESS["SUBSCRIBE__POPUP__CLOSE"] = "Close";
$MESS["SUBSCRIBE__POPUP__EMAIL"] = "Email";
$MESS["SUBSCRIBE__POPUP__MESSAGE_SUCCESS"] = "A confirmation code has been sent to the subscription address.";
$MESS["SUBSCRIBE__POPUP__SETTINGS"] = "Settings";
$MESS["SUBSCRIBE__POPUP__SUBMIT"] = "Subscribe to";
$MESS["SUBSCRIBE__POPUP__TITLE"] = "Subscribe to the newsletter";
$MESS["SUBSCRIBE__POPUP__TITLE_SUCCESS"] = "Thank!";
$MESS["SUBSCRIBE__POPUP__VALIDATE_LICENSES"] = "Agree to the terms";
?>