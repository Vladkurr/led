<?
$MESS["ADD_USER"] = "Subscribe to";
$MESS["EMAIL_INPUT"] = "Email";
?>