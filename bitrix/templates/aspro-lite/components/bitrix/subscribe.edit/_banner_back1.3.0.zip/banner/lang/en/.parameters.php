<?
$MESS["T_PAGE"] = "Subscription page";
?>