<?
$MESS ['ADD_USER'] = "Подписаться";
$MESS ['EMAIL_INPUT'] = "E-mail";
?>