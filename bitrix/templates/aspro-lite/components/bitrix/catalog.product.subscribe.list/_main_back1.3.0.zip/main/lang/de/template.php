<?
$MESS["CPSL_TPL_MESS_BTN_DETAIL"] = "Details";
$MESS["CPSL_ADD_TO_BASKET_OK"] = "Zu Ihrem Warenkorb hinzugefьgt";
$MESS["CPSL_CATALOG_TITLE_ERROR"] = "Fehler";
$MESS["CPSL_CATALOG_TITLE_BASKET_PROPS"] = "Produkteigenschaften, die zum Warenkorb hinzugefьgt werden sollen";
$MESS["CPSL_CATALOG_BASKET_UNKNOWN_ERROR"] = "Unbekannter Fehler beim Hinzufьgen eines Produktes zum Warenkorb";
$MESS["CPSL_CATALOG_BTN_MESSAGE_CLOSE"] = "SchlieЯen";
$MESS["CPSL_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "Warenkorb anzeigen";
$MESS["CPSL_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Auswдhlen";
$MESS["CPSL_TPL_MESS_BTN_SUBSCRIBE_DELETE"] = "Lцschen";
$MESS["CPSL_STATUS_SUCCESS"] = "Erfolgreich";
$MESS["CPSL_STATUS_ERROR"] = "Das ist ein Fehler.";
$MESS["CPSL_TITLE_PAGE_WHEN_ACCESSING"] = "Zugriff auf Abonnementverwaltung wiederherstellen";
$MESS["CPSL_HEADLINE_FORM_SEND_CODE"] = "Geben Sie Kontakt ein, an den Bestдtigungscode gesendet werden soll";
$MESS["CPSL_CONTACT_TYPE_SELECTION"] = "Kontakttyp auswдhlen";
$MESS["CPSL_CONTACT_TYPE_NAME"] = "Kontakt";
$MESS["CPSL_BUTTON_SUBMIT_CODE"] = "Code senden";
$MESS["CPSL_HEADLINE_FORM_FOR_ACCESSING"] = "Geben Sie den Bestдtigungscode ein, um fortzufahren";
$MESS["CPSL_CODE_LABLE"] = "Bestдtigungscode";
$MESS["CPSL_BUTTON_SUBMIT_ACCESS"] = "Zugriff anfordern";
$MESS["CPSL_IDENTIFICATION_REQUEST_OK"] = "Bestдtigungscode wurde an Kontakt gesendet, den Sie angegeben haben";
$MESS["CPSL_IDENTIFICATION_REQUEST_FAIL"] = "Das ist ein Fehler.";
$MESS["CPSL_SUBSCRIBE_NOT_FOUND"] = "Sie haben noch kein Produkt abonniert.";
$MESS["CPSL_SUBSCRIBE_TITLE"] = "Sie haben folgende Produkte abonniert:";
$MESS["CPSL_SUBSCRIBE_TITLE_NEW"] = "Ihre Abonnements";
$MESS["CPSL_SUBSCRIBE_POPUP_TITLE_AUTHORIZE"] = "Auf Abonnements zugreifen";
$MESS["CPSL_SUBSCRIBE_POPUP_TITLE_IDENTIFICATION"] = "Auf Abonnements zugreifen";
$MESS["CPSL_SUBSCRIBE_POPUP_TITLE_UNSUBSCRIBE"] = "Abonnement fьr Produktbenachrichtigungen abbestellen";
$MESS["CPSL_SUBSCRIBE_PAGE_TITLE_AUTHORIZE"] = "Um Abonnements anzuzeigen, sollten Sie sich 
<a href=\"javascript:void(0);\" id=\"cpsl-auth\">einloggen</a> oder 
<a href=\"javascript:void(0);\" id=\"cpsl-identification\">einen Zugriffscode anfordern</a>
";
$MESS["CPSL_TPL_MESS_BTN_UNSUBSCRIBE"] = "Abbestellen";
?>