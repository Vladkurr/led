<?
$MESS["CPSL_TPL_MESS_BTN_DETAIL"] = "Details";
$MESS["CPSL_ADD_TO_BASKET_OK"] = "Added to your shopping cart";
$MESS["CPSL_CATALOG_TITLE_ERROR"] = "Error";
$MESS["CPSL_CATALOG_TITLE_BASKET_PROPS"] = "Item properties to pass to shopping cart";
$MESS["CPSL_CATALOG_BASKET_UNKNOWN_ERROR"] = "Unknown error adding an item to shopping cart";
$MESS["CPSL_CATALOG_BTN_MESSAGE_CLOSE"] = "Close";
$MESS["CPSL_CATALOG_BTN_MESSAGE_BASKET_REDIRECT"] = "View shopping cart";
$MESS["CPSL_CATALOG_BTN_MESSAGE_SEND_PROPS"] = "Select";
$MESS["CPSL_TPL_MESS_BTN_SUBSCRIBE_DELETE"] = "Delete";
$MESS["CPSL_STATUS_SUCCESS"] = "Success";
$MESS["CPSL_STATUS_ERROR"] = "That's an error.";
$MESS["CPSL_TITLE_PAGE_WHEN_ACCESSING"] = "Restore subscription management access";
$MESS["CPSL_HEADLINE_FORM_SEND_CODE"] = "Enter contact to send confirmation code to";
$MESS["CPSL_CONTACT_TYPE_SELECTION"] = "Select contact type";
$MESS["CPSL_CONTACT_TYPE_NAME"] = "Contact";
$MESS["CPSL_BUTTON_SUBMIT_CODE"] = "Send code";
$MESS["CPSL_HEADLINE_FORM_FOR_ACCESSING"] = "Enter confirmation code to continue";
$MESS["CPSL_CODE_LABLE"] = "Confirmation code";
$MESS["CPSL_BUTTON_SUBMIT_ACCESS"] = "Get access";
$MESS["CPSL_IDENTIFICATION_REQUEST_OK"] = "Confirmation code has been sent to the contact you have provided";
$MESS["CPSL_IDENTIFICATION_REQUEST_FAIL"] = "That's an error.";
$MESS["CPSL_SUBSCRIBE_NOT_FOUND"] = "You are not subscribed to any product.";
$MESS["CPSL_SUBSCRIBE_TITLE"] = "You are subscribed for these products";
$MESS["CPSL_SUBSCRIBE_TITLE_NEW"] = "Your subscriptions";
$MESS["CPSL_SUBSCRIBE_POPUP_TITLE_AUTHORIZE"] = "Access subscriptions";
$MESS["CPSL_SUBSCRIBE_POPUP_TITLE_IDENTIFICATION"] = "Access subscriptions";
$MESS["CPSL_SUBSCRIBE_POPUP_TITLE_UNSUBSCRIBE"] = "Unsubscribe from product notifications";
$MESS["CPSL_SUBSCRIBE_PAGE_TITLE_AUTHORIZE"] = "To view subscriptions, please 
<a href=\"javascript:void(0);\" id=\"cpsl-auth\">log in</a> or 
<a href=\"javascript:void(0);\" id=\"cpsl-identification\">get access code</a>";
$MESS["CPSL_TPL_MESS_BTN_UNSUBSCRIBE"] = "Unsubscribe";
?>