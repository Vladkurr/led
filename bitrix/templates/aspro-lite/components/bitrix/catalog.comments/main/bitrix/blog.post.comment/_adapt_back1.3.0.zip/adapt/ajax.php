<?//require($_SERVER["DOCUMENT_ROOT"]."/bitrix/templates/aspro-lite/components/bitrix/catalog.comments/main/ajax.php"); ?>
<? require(__DIR__."/../../../ajax.php"); ?>