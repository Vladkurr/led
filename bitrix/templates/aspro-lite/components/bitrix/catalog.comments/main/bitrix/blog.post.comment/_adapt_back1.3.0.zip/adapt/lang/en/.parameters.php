<?
$MESS["B_SEO_USER"] = "Prevent search bots from indexing a link to a user profile";
?>