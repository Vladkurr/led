<?
$MESS["SPS_CHAIN_MAIN"] = "My account";
$MESS["SPS_CHAIN_SUBSCRIBE"] = "User subscriptions";
$MESS["SPS_TITLE_SUBSCRIBE"] = "My subscriptions";
$MESS["SPS_CHAIN_SUBSCRIBE_NEW"] = "Your subscriptions";
?>