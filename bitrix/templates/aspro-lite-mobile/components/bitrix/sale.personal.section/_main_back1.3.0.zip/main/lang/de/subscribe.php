<?
$MESS["SPS_CHAIN_MAIN"] = "Mein Account";
$MESS["SPS_CHAIN_SUBSCRIBE"] = "Nutzerabonnements";
$MESS["SPS_TITLE_SUBSCRIBE"] = "Meine Abonnements";
$MESS["SPS_CHAIN_SUBSCRIBE_NEW"] = "Ihre Abonnements";
?>