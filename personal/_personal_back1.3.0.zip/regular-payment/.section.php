<?
$sSectionName = "Регулярные платежи";
$arDirProperties = array(

);
?>