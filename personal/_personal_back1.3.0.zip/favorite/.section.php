<?
$sSectionName = "Избранные товары";
$arDirProperties = Array(
   "lmenu" => "да"
);?>