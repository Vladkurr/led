<?
$sSectionName = "Подписка на новости";
$arDirProperties = array(
	"lmenu" => "да"
);
?>