<?
$aMenuLinks = Array(
	Array(
		"Заказы", 
		"/personal/order/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Корзина", 
		"/personal/cart/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Регулярные платежи", 
		"/personal/regular-payment/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Профили покупателя", 
		"/personal/customer-profiles/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Счет пользователя", 
		"/personal/account/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>