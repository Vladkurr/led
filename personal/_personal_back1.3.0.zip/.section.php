<?
$sSectionName = "Личный кабинет";
$arDirProperties = Array(
    "MENU" => "Y"
);
?>