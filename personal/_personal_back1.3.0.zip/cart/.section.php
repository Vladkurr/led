<?
$sSectionName = "Корзина";
$arDirProperties = array(

);
?>