<?
$sSectionName = "Сменить пароль";
$arDirProperties = Array(
   "lmenu" => "да"
);
?>