<?
$sSectionName = "Профили покупателя";
$arDirProperties = array(

);
?>