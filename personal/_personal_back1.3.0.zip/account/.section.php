<?
$sSectionName = "Счет пользователя";
$arDirProperties = array(

);
?>