<?
$sSectionName = "Оплата заказа";
$arDirProperties = Array(

);
?>